const N = 10;  // Tamanho do labirinto NxN
const labirinto = Array.from({ length: N }, () => Array(N).fill(0));
const queijo = [0, 0];
const numRatos = 5;
let ratos = [];

function gerarParedes() {
    for (let i = 0; i < N; i++) {
        for (let j = 0; j < N; j++) {
            if ((i !== queijo[0] || j !== queijo[1]) && Math.random() < 0.3) {
                labirinto[i][j] = 1;
            }
        }
    }
}

function imprimirLabirinto() {
    const labirintoDiv = document.getElementById('labirinto');
    labirintoDiv.innerHTML = labirinto.map(linha => linha.join(' ')).join('<br>');
}

function iniciarLabirinto() {
    gerarParedes();
    imprimirLabirinto();

    for (let i = 0; i < numRatos; i++) {
        const ratoWorker = new Worker('ratoWorker.js');
        ratos.push(ratoWorker);

        const posicaoInicial = [Math.floor(Math.random() * N), Math.floor(Math.random() * N)];
        while (labirinto[posicaoInicial[0]][posicaoInicial[1]] !== 0) {
            posicaoInicial[0] = Math.floor(Math.random() * N);
            posicaoInicial[1] = Math.floor(Math.random() * N);
        }

        ratoWorker.postMessage({ id: i + 1, posicao: posicaoInicial, queijo, N, labirinto });

        ratoWorker.onmessage = function(event) {
            const { id, posicao } = event.data;
            labirinto[posicao[0]][posicao[1]] = id;
            imprimirLabirinto();
        };
    }
}
